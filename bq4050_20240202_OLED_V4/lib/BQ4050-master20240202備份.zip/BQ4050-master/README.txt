Lorro BQ4050

Arduino library for BQ4050 battery fuel gauge, using SMBUS communication which is based on I2C
