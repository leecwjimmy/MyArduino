# ESP32 TTGO Display Voltmeter

- A voltmeter based in ESP32 TTGO Display along with voltage divider resistors.

## Preview

![image](https://user-images.githubusercontent.com/72920953/159148738-77497618-470a-4562-92a8-121e58812c34.png)

## Video Demonstration

[![cafe-inventory-app-demo-yt](https://img.youtube.com/vi/7FOXZU-rPUE/0.jpg)](https://www.youtube.com/watch?v=7FOXZU-rPUE) 
